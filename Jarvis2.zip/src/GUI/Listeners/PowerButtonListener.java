package GUI.Listeners;

/**
 * Created by lukas on 25.03.15.
 */
public class PowerButtonListener {
}
