import javax.swing.*;
import java.awt.*;

public class test {
    public static void main(String args[])
    {
        String s[]={"reminder","period","s","Pizza","10"};
        new Time().executeAction(s);
        /*
        JFrame jf=new JFrame();
        jf.setSize(100, 300);
        JTextPane jl=new JTextPane();
        jl.setText("adsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdfadsf test asdf");
        jl.setEditable(false);
        jl.setOpaque(false);
        jl.setBackground(new Color(0,0,0,0));
        JPanel jp=new JPanel(new BorderLayout());
        jp.add(jl,BorderLayout.CENTER);
        jf.add(jp);
        jf.setVisible(true);
        */
    }
}