package logic;

/**
 * Created by lukas on 26.03.15.
 */
public class Verifyer {
    public static boolean verify(String signature)
    {
        return signature.equalsIgnoreCase("asdf");
    }
}
