package API.GUI;

import javax.swing.*;

/**
 * Created by lukas on 09.04.15.
 */
public abstract class AbstractSettingsPanel extends JPanel
{
    public abstract boolean save();
}
