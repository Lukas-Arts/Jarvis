sudo apt-get install espeak
