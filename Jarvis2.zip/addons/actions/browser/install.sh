sudo apt-get install xdg-utils
